//
//  HomeViewModel.swift
//  BaitapHomeScreen
//
//  Created by PCI0008 on 2/5/20.
//  Copyright © 2020 PCI0008. All rights reserved.
//

import Foundation

class HomeViewModel {
    var images: [String] = ["Cho", "Nai", "Soc", "Voi", "Vuon"]
}
