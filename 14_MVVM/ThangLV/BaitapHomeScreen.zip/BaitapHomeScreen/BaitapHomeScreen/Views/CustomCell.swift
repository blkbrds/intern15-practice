//
//  CustomCell.swift
//  BaitapHomeScreen
//
//  Created by PCI0008 on 2/4/20.
//  Copyright © 2020 PCI0008. All rights reserved.
//

import UIKit

class CustomCell: UICollectionViewCell {
    
    // MARK: - IBOutlet
    @IBOutlet weak var descriptionImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    
    //MARK: - IBAction
    @IBAction func favoriteButtonTouchUpInside(_ sender: Any) {
        if favoriteButton.isSelected == true {
            favoriteButton.isSelected = false
        } else {
            favoriteButton.isSelected = true
        }
        favoriteButton.setImage(UIImage.init(systemName: "star"), for: .normal)
        favoriteButton.setImage(UIImage.init(systemName: "star.fill"), for: .selected)
    }
}
