//
//  CommentTableViewCell.swift
//  BaitapHomeScreen
//
//  Created by PCI0008 on 2/6/20.
//  Copyright © 2020 PCI0008. All rights reserved.
//

import UIKit

class CommentTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
