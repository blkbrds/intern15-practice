//
//  CommentTableViewCell.swift
//  BaitapHomeScreen
//
//  Created by PCI0008 on 2/6/20.
//  Copyright © 2020 PCI0008. All rights reserved.
//

import UIKit

final class CommentTableViewCell: UITableViewCell {
    
}
