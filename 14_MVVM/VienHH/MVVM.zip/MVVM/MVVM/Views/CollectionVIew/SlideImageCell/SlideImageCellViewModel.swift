//
//  SlideImageCellViewModel.swift
//  MVVM
//
//  Created by user on 2/5/20.
//  Copyright © 2020 VienH. All rights reserved.
//

import Foundation

final class SlideImageCellViewModel {

    var imageName: String

    init(imageName: String) {
        self.imageName = imageName
    }
}
