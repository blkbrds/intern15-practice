//
//  DetailViewModel.swift
//  MVVM
//
//  Created by user on 2/7/20.
//  Copyright © 2020 VienH. All rights reserved.
//

import UIKit

class DetailViewModel: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
