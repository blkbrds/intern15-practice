//
//  DetailViewController.swift
//  MVVM
//
//  Created by user on 2/6/20.
//  Copyright © 2020 VienH. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
