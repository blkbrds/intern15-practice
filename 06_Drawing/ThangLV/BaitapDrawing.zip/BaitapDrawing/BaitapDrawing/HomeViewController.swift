import UIKit

class HomeViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let view = ColumnChartDraw()
        view.backgroundColor = .white
        self.view = view
        print(UIScreen.main.bounds)
    }
}
